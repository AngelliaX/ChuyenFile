﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerNetworking : MonoBehaviour {


	public gameObject playerCamera;
	//[SerializeField]private MonoBehaviour[] scriptsToIgnore;


	//private PhotonView photonView;

	// Use this for initialization
	void Start () {
	//	photonView = GetComponent<PhotonView> ();
		Initialize ();
	}
	void Initialize(){
		if (playerCamera.isMine) {
          
		} else {
			playerCamera.SetActive (false);
			
		}
	}
}
