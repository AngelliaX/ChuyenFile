﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuanLyButton : MonoBehaviour {
    public static QuanLyButton instance;
    public GameObject Pause;
    public GameObject Lose;
    public GameObject Win;
    public GameObject theme,chatpanel;
    public GameObject big;
    public static string ten = "RandomGuy";
    bool mod = false;
    public GameObject input, button,nightmode;
    public Text thongbao;
    void Awake()
    {
        _MakeInstance();
    }
    void _MakeInstance()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    public void StartGame()
    {
        Application.LoadLevel("Game");
    }
    public void OnlineGame()
    {
        if (Application.internetReachability != NetworkReachability.NotReachable)
        {
            Application.LoadLevel("OnlineGame");
            if (GameObject.Find("PlayerName").GetComponent<InputField>().text == "")
            {
                ten = "KhongCoTen";
            }
            else
            {
                ten = GameObject.Find("PlayerName").GetComponent<InputField>().text;
            }
        }
        else
        {
            thongbao.text = "Kiem tra ket noi mang";
        }

    }
    public void mode()
    {
        if (mod == false)
        {
            nightmode.gameObject.SetActive(true);
            mod = true;
        }
        else
        {
            nightmode.gameObject.SetActive(false);
            mod = false;
        }
    }
    public void Chat()
    {
        Application.LoadLevel("SampleScene");
    }
    public void turnback()
    {
        big.gameObject.SetActive(false);
        theme.gameObject.SetActive(true);
        chatpanel.gameObject.SetActive(true);
    }
    public void turnon()
    {
        big.gameObject.SetActive(true);
        theme.gameObject.SetActive(false);
        chatpanel.gameObject.SetActive(false);
    }
    public void PausePanel()
    {
        Time.timeScale = 0;
        Pause.gameObject.SetActive(true);
    }

    public void ChoiLai()
    {
        Application.LoadLevel("Game");
    }
    public void Back()
    {
        Time.timeScale = 1;
        Pause.gameObject.SetActive(false);
    }
    public void Menu()
    {
        Application.LoadLevel("MainMenu");
    }
    public void LosePanel(int score)
    {
        Lose.gameObject.SetActive(true);

        DiemSo.instance.endScoreText.text = "" + score;
        if (score > GameManager.instance.GetHighScore())
        {
            GameManager.instance.SetHighScore(score);
        }
        DiemSo.instance.bestScoreText.text = "" + GameManager.instance.GetHighScore();
    }

    public void WinPanel(int score)
    {       
        Win.gameObject.SetActive(true);
        DiemSo.instance.Phadao.text = "" + score;
        GameManager.instance.SetHighScore(score);
    }
}
