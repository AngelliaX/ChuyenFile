﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private float speed = 5f;

    //private Animator anim;
    private bool playerMoving = false;
    private Vector2 lastMove;
    //private PhotonView photonView;

    Touch touch;
    Vector3 touchPosition, whereToMove;
    Rigidbody2D rb;
    public Camera cam;
    float previousDistanceToTouchPos, currentDistanceToTouchPos;
    // Use this for initialization
    void Start()
    {
       // anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        //photonView = GetComponent<PhotonView>();
    }

    // Update is called once per frame
    void Update()
    {
        //if (photonView.isMine)
        //{
            if (Input.GetAxisRaw("Horizontal") > 0.5f || Input.GetAxisRaw("Horizontal") < -0.5f)
            {
                transform.Translate(new Vector3(Input.GetAxisRaw("Horizontal") * speed * Time.deltaTime, 0f, 0f));
                playerMoving = true;
                lastMove = new Vector2(Input.GetAxisRaw("Horizontal"), 0f);
            }
            if (Input.GetAxisRaw("Vertical") > 0.5f || Input.GetAxisRaw("Vertical") < -0.5f)
            {
                transform.Translate(new Vector3(0f, Input.GetAxisRaw("Vertical") * speed * Time.deltaTime, 0f));
                playerMoving = true;
                lastMove = new Vector2(0f, Input.GetAxisRaw("Vertical"));
            }

            if (playerMoving)
            {
                currentDistanceToTouchPos = (touchPosition - transform.position).magnitude;

            }
            if (Input.GetMouseButtonDown(0))
            {
                touchPosition = cam.ScreenToWorldPoint(Input.mousePosition);
                

                previousDistanceToTouchPos = 0;
                currentDistanceToTouchPos = 0;

                playerMoving = true;
                whereToMove = (touchPosition - transform.position).normalized;
                rb.velocity = new Vector2(whereToMove.x * speed, whereToMove.y * speed);

            }
            if (Input.touchCount > 0)
            {
                touch = Input.GetTouch(0);
                if (touch.phase == TouchPhase.Began)
                {
                    previousDistanceToTouchPos = 0;
                    currentDistanceToTouchPos = 0;
                    playerMoving = true;
                    touchPosition = cam.ScreenToWorldPoint(touch.position);
                    touchPosition.z = 1;
                    whereToMove = (touchPosition - transform.position).normalized;

                    rb.velocity = new Vector2(whereToMove.x * speed, whereToMove.y * speed);
                }
            }
            if (currentDistanceToTouchPos > previousDistanceToTouchPos)
            {
                playerMoving = false;
                rb.velocity = Vector2.zero;
                currentDistanceToTouchPos = 0;

            }
            if (playerMoving)
            {
                previousDistanceToTouchPos = (touchPosition - transform.position).magnitude;

            }

            // anim.SetFloat("MoveX", whereToMove.x);
            // anim.SetFloat("MoveY", whereToMove.y);
            /// anim.SetBool("PlayerMoving", playerMoving);
            // anim.SetFloat("LastMoveX", rb.velocity.x);
            // anim.SetFloat("LastMoveY", rb.velocity.y);
        //}

    }
}
