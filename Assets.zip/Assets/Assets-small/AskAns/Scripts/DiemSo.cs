﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DiemSo : MonoBehaviour {

    public static DiemSo instance;
    public Text liveText, scoreText, endScoreText, bestScoreText,Phadao;

    void Awake()
    {
        _MakeInstance();
    }
    void _MakeInstance()
    {
        if(instance == null)
        {
            instance = this;
        }
    }
    public void _SetScore(int score)
    {
        scoreText.text = " " + score; 
    }

    public void _Live(int live)
    {
        liveText.text = live.ToString();
    }

   
}
