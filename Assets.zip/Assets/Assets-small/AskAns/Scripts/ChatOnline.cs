﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using ExitGames.Client.Photon.Chat;
using System.Collections.Generic;

public class ChatOnline : MonoBehaviour, IChatClientListener
{

    public ChatClient chatClient;
    public string username = "RandomGuy";
   // public Text info;
    public InputField msg;
    public GameObject chat2;
    public GameObject chat1;
    public GameObject textObject1,textObject2;
    public List<Message> messageList1 = new List<Message>();
    public List<Message3> messageList2 = new List<Message3>();
    public int maxMess = 25;

    void Start()
    {

        Application.runInBackground = true;

        if (string.IsNullOrEmpty(PhotonNetwork.PhotonServerSettings.ChatAppID))
        {
            Debug.LogError("You need to set the chat app ID in the PhotonServerSettings file in order to continue.");
            return;
        }
        Random r = new Random();
        username = QuanLyButton.ten;
        this.chatClient = new ChatClient(this);
        this.chatClient.Connect(PhotonNetwork.PhotonServerSettings.ChatAppID, "1.0", new ExitGames.Client.Photon.Chat.AuthenticationValues(username));
        Debug.Log("Connecting as: " + username);
       // info.text = "Connecting";

    }
    void Update()
    {

        if (this.chatClient != null)
        {
            this.chatClient.Service(); // make sure to call this regularly! it limits effort internally, so calling often is ok!
        }

    }
    public void OnConnected()
    {
        print("******************       Connected");
        this.chatClient.Subscribe(new string[] { "globle" });
       // info.text = "Connected";
        this.chatClient.SetOnlineStatus(ChatUserStatus.Online);

    }
    public void sendMsg()
    {      
        this.chatClient.PublishMessage("globle", msg.text);
        msg.text = "";
    }
    public void disconnect()
    {
        Application.LoadLevel("MainMenu");
        PhotonNetwork.Disconnect(); 
    }
    public void OnDisconnectedFromPhoton()
    {
        
    }
    public void OnDisconnected()
    { }
    public void OnGetMessages(string channelName, string[] senders, object[] messages)
    {
       
        if (messageList1.Count >= 10)
        {
            Destroy(messageList1[0].textObject.gameObject);
            messageList1.Remove(messageList1[0]);
        }
        if (messageList2.Count >= maxMess)
        {
            Destroy(messageList2[0].textObject.gameObject);
            messageList2.Remove(messageList2[0]);
        }
        for (int i = 0; i < senders.Length; i++)
        {
            Message newMessage1 = new Message();
            newMessage1.text = "" + senders[i] + " : " + messages[i];
            Message3 newMessage2 = new Message3();
            newMessage2.text = "" + senders[i] + " : " + messages[i];

            GameObject newText1 = Instantiate(textObject1, chat1.transform);
            newMessage1.textObject = newText1.GetComponent<Text>();
            newMessage1.textObject.text = newMessage1.text;
            messageList1.Add(newMessage1);

            GameObject newText2 = Instantiate(textObject2, chat2.transform);
            newMessage2.textObject = newText2.GetComponent<Text>();
            newMessage2.textObject.text = newMessage2.text;
            messageList2.Add(newMessage2);
        }     
    }   
    public void OnPrivateMessage(string sender, object message, string channelName)
    { }
    public void OnSubscribed(string[] channels, bool[] results)
    {
        foreach (string channel in channels)
        {
            this.chatClient.PublishMessage(channel, "da ket noi"); // you don't HAVE to send a msg on join but you could.
        }
    }
    public void OnUnsubscribed(string[] channels)
    { }
    public void OnStatusUpdate(string user, int status, bool gotMessage, object message)
    {
    }
    public void DebugReturn(ExitGames.Client.Photon.DebugLevel level, string message)
    { }
    public void OnChatStateChange(ChatState state)
    { }
}

public class Message
{
    public string text;
    public Text textObject;
}
public class Message3
{
    public string text;
    public Text textObject;
}

