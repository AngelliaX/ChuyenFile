﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
public class ChangeText : MonoBehaviour {

    public static ChangeText instance;
    public AudioSource audio;
    public AudioClip correct, wrong, lose,win;

    public Text cauhoi;
    public Text thongbao;
    public InputField cautraloi;
    public int lives = 3;
    public int score = 0;
    int a = 0;
    bool b = false;
    /* private void Update()
     {
         if(cauhoi.text == Question[2])
         {
             thongbao.text = "Xin chao";
         }
     }*/
    public List<string> Question = new List<string>();
    List<string> Answer = new List<string>();
    private void Start()
    {
        Question.Add("1 + 1 = mấy");
        Question.Add("69 + 96 = ?");
        Question.Add("Ai là tổng thống mỹ hiện nay");
        Question.Add("Nhập đoạn văn sau: HmMmMm");
        Question.Add("Cây gì không lá, không hoa,Sáng đêm sinh nhật cả nhà vây quanh?");
        Question.Add("Quả gì không phải để ăn,Mà dùng để đá, để lăn để chuyền?");
        Question.Add("Có chân mà chẳng biết đi,Có mặt phẳng lí cho bé ngồi lên,Là cái gì?");
        Question.Add("Con gì không thích ăn cơm,Mà lại ăn lửa, ăn nước, ăn than?");
        Question.Add("Con gì nhỏ bé,Mà hát khỏe ghê,Suốt cả mùa hè,Râm ran hợp xướng?");    
        Question.Add("Quần gì rộng nhất?");
        Question.Add("Cái gì mà đi thì nằm, đứng cũng nằm, nhưng khi nằm lại đứng?");
        Question.Add("Cái gì mà tay trái cầm được nhưng tay phải cầm không được?");
        Question.Add("Loại nước giải khát nào chứa sắt và canxi?");
        Question.Add("Xã nào đông dân nhất?");
        Question.Add("Ai cũng biết đỉnh núi Everest cao nhất thế giới, vậy trước khi đỉnh Everest được khám phá, thì đỉnh núi nào là cao nhất thế giới?");
        Question.Add("Sở thú bị cháy ,đố bạn con gì chạy ra đầu tiên?");
        Question.Add("Giả sử vào tầm 12h đêm nay trời đổ mưa. Vậy theo bạn, trong khoảng 72h tới trời có hửng nắng không?");
        Question.Add("Ai là người khác biệt nhất: Geogre Washington, Sherlock Holmes, William Shakespeare, Ludwig van Beethoven, Napoléon Bonaparte?");
        Question.Add("Đoán xem");


        Answer.Add("mấy");
        Answer.Add("?");
        Answer.Add("donald trump");
        Answer.Add("hmmmmm");
        Answer.Add("cay nen");
        Answer.Add("qua bong");
        Answer.Add("cai ghe");
        Answer.Add("con tau");
        Answer.Add("con ve");
        Answer.Add("quan dao");
        Answer.Add("ban chan");
        Answer.Add("tay phai");
        Answer.Add("cafe");       
        Answer.Add("xa hoi");
        Answer.Add("everest");
        Answer.Add("con nguoi");
        Answer.Add("khong");
        Answer.Add("sherlock holmes");
        Answer.Add("deo doan");

        int ran = Random.Range(0, 0);     
    }
    public void Ok()
    {
        
        int ran = Random.Range(0, Question.Count -1);
        string answer = cautraloi.text;
        if (b == false)
        {
            if (answer.ToLower() == "san sang")
            {
                cauhoi.text = Question[ran];
                a = ran;
                b = true;
                thongbao.text = "";
                cautraloi.text = "";
                audio.PlayOneShot(correct);
            }
            else
            {
                thongbao.text = "Ghi 'san sang'";
                audio.PlayOneShot(wrong);
                cautraloi.text = "";
            }
        }
        else
        {
            if (Question.Count != 1)
            {
                if (answer.ToLower() == Answer[a])
                {
                    Question.RemoveAt(a);
                    Answer.RemoveAt(a);
                    cauhoi.text = Question[ran];
                    a = ran;
                    thongbao.text = "";
                    score++;
                    if (DiemSo.instance != null)
                    {
                        DiemSo.instance._SetScore(score);
                    }
                    audio.PlayOneShot(correct);
                    cautraloi.text = "";

                }
                else
                {
                    if (lives != 0)
                    {
                        lives--;
                        thongbao.text = "Sai r ";
                        audio.PlayOneShot(wrong);
                        DiemSo.instance._Live(lives);
                        cautraloi.text = "";
                    }
                    else
                    {
                        if (QuanLyButton.instance != null)
                        {
                            audio.PlayOneShot(lose);
                            QuanLyButton.instance.LosePanel(score);
                        }
                    }
                }
            }
            else
            {
                if (QuanLyButton.instance != null)
                {
                    audio.PlayOneShot(win);                                   
                    QuanLyButton.instance.WinPanel(score);
                }
            }
        }
    }
   
}