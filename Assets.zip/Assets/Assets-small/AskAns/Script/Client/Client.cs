﻿using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.IO;
using System;


public class Client : MonoBehaviour
{
    public static Client instance;
    private bool socketReady;
    private TcpClient socket;
    private NetworkStream stream;
    private StreamWriter writer;
    private StreamReader reader;
    private NetworkConnection network;

    public string clientName = "Client";
    public NetworkIdentity networkClient;

    public GameObject chatContainer;
    public GameObject chatbox;
    public GameObject textObject;
    public Text thongbao;
    public GameObject LoginPanel;
    public List<Message> messageList = new List<Message>();
    public GameObject big;
    public int maxMess = 25;

    public void ConnectToServer()
    {

        // Si deja connecté, ignorez cette methode
        if (socketReady)
            return;

        // IP et port par défaut
        string host = "127.0.0.1";
        int port = 1411;
        //string login = "";

        // Remplace les valeurs par défaut par celle saisies dans les champs
        string h;  // HostInput
        int p;  // PortInput
        string l;  // Login


        l = GameObject.Find("Name").GetComponent<InputField>().text;
        if (l != "")
        {
            clientName = l;
        }
        else
        {
            clientName = "RandomGuy";
        }

        h = GameObject.Find("HostInput").GetComponent<InputField>().text;
        if (h != "")
            host = h;

        int.TryParse(GameObject.Find("PortInput").GetComponent<InputField>().text, out p);
        if (p != 0)
            port = p;


        // On créé la connexion
        try
        {

            socket = new TcpClient(host, port);
            stream = socket.GetStream();
            writer = new StreamWriter(stream);
            reader = new StreamReader(stream);
            socketReady = true;
            LoginPanel.gameObject.SetActive(false);
        }
        catch (Exception e)
        {
            thongbao.text = "Vui Long Kiem Tra Lai IP Va Port";
            Debug.Log(" Socket Error : " + e.Message + " IP = " + host + " et Port = " + port);
        }
    }

    /*
    public void DisconnectFromServer()
    {
    try
    {
    // GameObject.Find("Deconnexion").GetComponent<Button>().OnClick.RemoveAllListeners();
    // GameObject.Find("Deconnexion").GetComponent<Button>().OnClick.AddListener(MonoBehaviour.singleton.StopHost);
    // network = new NetworkConnection();
    // network.Disconnect();
    Network.CloseConnection(Network.connections[1], true);
    }
    catch(Exception e)
    {
    Debug.Log("error message : " + e.Message);
    }
    }
    */

    private void Update()
    {
        if (socketReady)
        { 
            if (stream.DataAvailable)
            {
                string data = reader.ReadLine();
                if (data != null)
                {
                    OnIncomingData(data);
                }
            }
        }
    }

    private void OnIncomingData(string data)
    {
        if (messageList.Count >= maxMess)
        {
            Destroy(messageList[0].textObject.gameObject);
            messageList.Remove(messageList[0]);
        }
        Message newMessage = new Message();
        newMessage.text = data;

        GameObject newText2 = Instantiate(textObject, chatbox.transform);
        newText2.GetComponent<Text>().text = data;

        GameObject newText = Instantiate(textObject, chatContainer.transform);
        newMessage.textObject = newText.GetComponent<Text>();
        newMessage.textObject.text = newMessage.text;
        messageList.Add(newMessage);
        
    }

    public void Send(string data)
    {
        if (!socketReady)
            return;

        writer.WriteLine(data);
        writer.Flush();
    }

    public void OnSendButton()
    {
        if (big.gameObject.activeSelf == true)
        {
            string message = GameObject.Find("SendInput2").GetComponent<InputField>().text;
            Send(clientName + ": " + message);
            GameObject.Find("SendInput2").GetComponent<InputField>().text = "";
        }
        else
        {
            string message = GameObject.Find("SendInput").GetComponent<InputField>().text;
            Send(clientName + ": " + message);
            GameObject.Find("SendInput").GetComponent<InputField>().text = "";
        }
    }

    public void CloseSocket()
    {
        if (!socketReady)
            return;

        // Network.CloseConnection(networkClient, true);
        stream.Close();
        writer.Close();
        reader.Close();
        socket.Close();

        socketReady = false;
    }

    private void OnApplicationQuit()
    {
        CloseSocket();
    }

    private void OnDisable()
    {
        CloseSocket();
    }
}

public class Message2
{
    public string text;
    public Text textObject;
}
