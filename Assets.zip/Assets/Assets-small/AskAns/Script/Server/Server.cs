﻿using UnityEngine;
using System.Collections;
using System.Net.Sockets;
using System.Collections.Generic;
using System;
using System.Net;
using System.IO;

public class Server : MonoBehaviour
{
    private List<ServerClient> clients;
    private List<ServerClient> disconnectedList;

    public string ip = "127.0.0.1";
    private int portnb = 1411;
    private TcpListener server;
    private bool serverStarted;
    [SerializeField]private GameObject player;
    [SerializeField]private GameObject lobbyCamera;
    private void Start()
    {
        clients = new List<ServerClient>();
        disconnectedList = new List<ServerClient>();

        try
        {
            
            server = new TcpListener(IPAddress.Any, portnb);
            server.Start();
            
            StartListening();
            serverStarted = true;
            
            Debug.Log("Started on port: " + portnb.ToString());
			Instantiate(player,player.transform.position,Quaternion.identity);
			lobbyCamera.SetActive (false);
        }
        catch (Exception e)
        {
            Debug.Log("SERVER.CS - Socket Error : " + e.Message);
        }
    }

    private void Update()
    {
        if (!serverStarted)
            return;

        foreach(ServerClient c in clients)
        //for (int i = 0; i < clients.Count; i++)
        {
            //ServerClient c = clients[i];

            // Client tjrs connecté ?
            if (!IsConnected(c.tcp))
            {
                c.tcp.Close();
                disconnectedList.Add(c);
                //return;
               // clients.RemoveAt(i);
               // i--;

            }

            // Verif si message envoyé par client
            else
            {

                NetworkStream s = c.tcp.GetStream();

                if (s.DataAvailable)
                {
                    StreamReader reader = new StreamReader(s, true);
                    string data = reader.ReadLine();

                    if (data != null)
                        OnIncomingData(c, data);

                }
            }
        }
        // Affiche tableau des users connectés
        // Debug.Log("SERVEUR tableau users : " + clients.Count +"\t - Name = " + c.clientName + "\t - DECO = " + disconnectedList.Count);

        // Message 'User' s'est déconnecté
        for (int i = 0; i < disconnectedList.Count - 1; i++)
        {
            Broadcast(disconnectedList[i].clientName + " s'est déconnecté !", clients);

            //clients.Remove(disconnectedList[i]);
            //disconnectedList.RemoveAt(i);
        }
        disconnectedList.Clear();
        // Affiche tableau des users connectés
        //Debug.Log("SERVEUR tableau users : " + clients.Count + "\t - Name = " + c.clientName + "\t - DECO = " + disconnectedList.Count);
    }
    private void StartListening()
    {
        server.BeginAcceptTcpClient(AcceptTcpClient, server);
    }

    private bool IsConnected(TcpClient c)
    {
        try
        {
            if (c != null && c.Client != null && c.Client.Connected)
            {
                if (c.Client.Poll(0, SelectMode.SelectRead))
                {
                    return !(c.Client.Receive(new byte[1], SocketFlags.Peek) == 0);
                }
                return true;
            }
        }
        catch
        {
            return false;
        }
        return true; // empeche erreur : not all code paths return a value
    }

    private void AcceptTcpClient(IAsyncResult ar)
    {
        TcpListener listener = (TcpListener)ar.AsyncState;
        clients.Add(new ServerClient(listener.EndAcceptTcpClient(ar)));
        StartListening();      
        Broadcast("mot nguoi choi da ket noi", clients);
        //Broadcast("%NAME", new List<ServerClient>() { clients[clients.Count - 1] });
    }

    private void OnIncomingData(ServerClient c, string data)
    {
        //Debug.Log(c.clientName + " a écrit : " + data);
        if (data.Contains("&NAME"))
        {
            c.clientName = data.Split('|')[1];
            Broadcast(" connected ", clients);
            return;
        }
        Broadcast(data, clients);
    }

    private void Broadcast(string data, List<ServerClient> cl)
    {
        foreach (ServerClient c in cl)
        {
            try
            {
                StreamWriter writer = new StreamWriter(c.tcp.GetStream());
                writer.WriteLine(data);
                writer.Flush();

            }
            catch (Exception e)
            {
                Debug.Log("Message d'erreur : " + e.Message + " pour client : " + c.clientName);
            }
        }
    }
}

public class ServerClient
{
    public TcpClient tcp;
    public string clientName;

    public ServerClient(TcpClient clientSocket)
    {
        clientName = "MainName";
        tcp = clientSocket;

    }

}

